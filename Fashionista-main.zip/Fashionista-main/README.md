# MERN Stack - Ecommerce
> Ecommerce website built with the MERN stack with React Context API for state management, pure CSS for style

Heroku link: https://desolate-citadel-76747.herokuapp.com/


Snapshots

![Admin](https://user-images.githubusercontent.com/74426577/128706197-6a6b85f7-08ee-4754-a02e-68255677054c.PNG)
![AdminProducts](https://user-images.githubusercontent.com/74426577/128706292-37e955bb-2a9c-4677-a716-4b43b412c3ad.PNG)
![Caategories](https://user-images.githubusercontent.com/74426577/128706303-b0a9365d-f64e-45f0-899a-c9370c4202d5.PNG)
![Cart](https://user-images.githubusercontent.com/74426577/128706320-66ec00e7-d8f2-404c-9598-57f241271266.PNG)
![CreateProduct](https://user-images.githubusercontent.com/74426577/128706326-8118a883-2643-4906-8e63-d7bb34306c01.PNG)
![OrderDesc](https://user-images.githubusercontent.com/74426577/128706330-e747e248-d12e-4964-a089-d2a8dd0706f2.PNG)
![User - Products](https://user-images.githubusercontent.com/74426577/128706335-bee71e6a-92a0-4c20-9e44-539c7781e3e4.PNG)
![User OrderHistory](https://user-images.githubusercontent.com/74426577/128706340-e6abd861-c68e-49c1-9f0c-0360bc04029e.PNG)
![User](https://user-images.githubusercontent.com/74426577/128706346-26cda3cf-5243-42b4-b857-453a6c97e97e.PNG)
