import React from 'react';

const HomePage = () => {
    return(
        <div className="main_content">
            <h1 class="hometitle">Best<br />Outfits</h1>
            <h3 class="homesubtitle">Wear to be confident</h3>
        </div>
    );
}

export default HomePage